#include "parameters.h"
#include "AnalyticalSolution.h"
#include "ImplicitSchemes.h"
#include "Laasonen.h"
#include "CrankNicolson.h"
#include "DuFortFrankel.h"
#include "Richardson.h"
#include "ExplicitSchemes.h"

#include<iostream>
#include<vector>
#include<fstream>

int main()
{
	Parameters parameters = Parameters(); //Creation of the parameters object with all the data
	AnalyticalSolution analyticalSolution = AnalyticalSolution(parameters);
	DuFortFrankel dufort = DuFortFrankel(parameters);
	Richardson richardson = Richardson(parameters);

	std::vector<std::vector<double>> analyticalSolutions;
	
	//To generate the analytical solutions for the 5 time points.
	for (int unsigned i = 0; i < parameters.getOutputTimePoints().size(); i++) {
		analyticalSolutions.push_back(analyticalSolution.ComputeAnalyticalSolution(parameters, parameters.getOutputTimePoints()[i]));
	}


	Laasonen laasonen = Laasonen(parameters, 0);
	CrankNicolson crankNicolson = CrankNicolson(parameters, 0);

	//Need to change this into a printer
	laasonen.printLaasonen(parameters, 0);
	crankNicolson.printCrankNicolson(parameters, 0);

	dufort.solve(parameters, parameters.getVecDeltaT()[0], parameters.getTimePoints()[0]);
	richardson.solve(parameters, parameters.getVecDeltaT()[0], parameters.getTimePoints()[0]);

	//pour print le analytical	
	std::ofstream ofs("Analytical.csv");
	ofs << "x;0;0.05;0.1;0.15;0.20;0.25;0.30;0.35;0.40;0.45;0.50;0.55;0.60;0.65;0.70;0.75;0.80;0.85;0.90;0.95;1" << std::endl;

	for (int unsigned i = 0; i < analyticalSolutions.size(); i++) {
		std::cout << i << std::endl;
		ofs << parameters.getOutputTimePoints()[i] << ";";
		for (int unsigned x = 0; x < analyticalSolutions[i].size(); x++) {
			ofs << analyticalSolutions[i][x] << ";";
		}
		ofs << std::endl;
	}


	return 0;
}