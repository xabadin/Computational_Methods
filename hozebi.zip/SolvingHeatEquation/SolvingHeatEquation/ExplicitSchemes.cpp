#include "ExplicitSchemes.h"
#include<iostream>
#include<fstream>

ExplicitSchemes::ExplicitSchemes() {} //Default constructor

//Need to change variable names here
ExplicitSchemes::ExplicitSchemes(Parameters parameters) {
	this->v2 = std::vector<double>(parameters.getSpacePoints());
	this->v1 = std::vector<double>(parameters.getSpacePoints(), parameters.getInitialTemp());
	this->v0 = std::vector<double>(parameters.getSpacePoints(), parameters.getInitialTemp());
} //Constructor with parameters


void ExplicitSchemes::solve(Parameters parameters, double DeltaT, int meshsize_t) {

	std::string name = SchemeName(DeltaT);
	std::ofstream ofs(name + ".csv");
	ofs << "DeltaT = " << DeltaT << " DeltaX = " << parameters.getDeltaX() << std::endl;
	ofs << "x;0;0.05;0.1;0.15;0.20;0.25;0.30;0.35;0.40;0.45;0.50;0.55;0.60;0.65;0.70;0.75;0.80;0.85;0.90;0.95;1" << std::endl;



	for (int n = 0; n < meshsize_t; n++)
	{
		ofs << "t = " << n * DeltaT << " n = " << n << " ;";
		for (int i = 0; i < parameters.getSpacePoints(); i++)
		{
			if (i == 0 || i == parameters.getSpacePoints() - 1)
			{
				v2[i] = parameters.getSurfaceTemp();
			}
			else {
				v2[i] = NextTimeStep(parameters, i, DeltaT);
			}
		}

		for (int unsigned l = 0; l < v2.size();l++)
		{
			std::cout << v2[l] << " ";
			ofs << v2[l] << ";";
		}
		ofs << std::endl;
		//On remplace tt les vecteur, cad v0=v1 puis v1=v2 et on recalcule v2 en boucle
		if (n < meshsize_t) {
			v0 = v1;
			v1 = v2;
		}
	}
}